 let htmlSettingNames = [
    { name: 'smiles', position: 'first' },
    
    { name: 'asett', position: 'second' },
    { name: 'asettchat', position: 'second' },
	{ name: 'asettignore', position: 'second' },
    { name: 'chan', position: 'second' },
    
    { name: 'savetouser', position: 'third' },
    { name: 'wellcome', position: 'third' },
    { name: 'userstyles', position: 'third' },
    { name: 'changepassword', position: 'third' },
    { name: 'staypassword', position: 'third' },
    
    { name: 'alert', position: 'last' }
],
htmlCountNames = htmlSettingNames.length;